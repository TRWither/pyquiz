import ask
import choose
import guessnum
import randchoose
import randswer